class PagesController < ApplicationController
  def home
  end

  def dashboard
  end

  def project
  end

  def settings
  end
end
